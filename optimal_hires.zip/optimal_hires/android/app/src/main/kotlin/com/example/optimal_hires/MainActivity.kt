package com.example.optimal_hires

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
